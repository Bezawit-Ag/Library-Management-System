package com.poli.lms;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class MembersController implements Initializable {
    @FXML private AnchorPane membersContainer;
    @FXML private TableColumn<Member, Integer> MIDCol;
    @FXML private TableColumn<Member, String> departmentCol;
    @FXML private TableColumn<Member, String> genderCol;
    @FXML private TableView<Member> membersTable;
    @FXML private TableColumn<Member, String> nameCol;
    @FXML private TableColumn<Member, Integer> numberBorrowedCol;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        MIDCol.setCellValueFactory(new PropertyValueFactory<>("mid"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        departmentCol.setCellValueFactory(new PropertyValueFactory<>("department"));
        genderCol.setCellValueFactory(new PropertyValueFactory<>("gender"));
        numberBorrowedCol.setCellValueFactory(new PropertyValueFactory<>("numberBorrowed"));

        try {
            Database.connect();
            displayMembers(Database.connection);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void deleteMemberBtnHandler(ActionEvent event) {
        Member selectedMember = membersTable.getSelectionModel().getSelectedItem();

        if (selectedMember == null) {
            showSelectTableRowError();
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Member Confirmation");
        confirm.setHeaderText(null);
        confirm.setContentText("Are you sure you want to delete " + selectedMember.getName() + "?");

        confirm.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                try {
                    // Perform deletion
                    Database.removeMember(selectedMember.getMid());

                    // Refresh the table
                    membersTable.getItems().clear();
                    displayMembers(Database.connection);

                    // Show success alert
                    Alert success = new Alert(Alert.AlertType.INFORMATION);
                    success.setTitle("Member Deleted");
                    success.setHeaderText(null);
                    success.setContentText("Member deleted successfully.");
                    success.showAndWait();
                } catch (Exception e) {
                    e.printStackTrace();
                    Alert error = new Alert(Alert.AlertType.ERROR);
                    error.setTitle("Delete Error");
                    error.setHeaderText("Could not delete member");
                    error.setContentText(e.getMessage());
                    error.showAndWait();
                }
            }
        });
    }

    public void showSelectTableRowError() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Member Error Dialog");
        alert.setHeaderText("First Select The Table Row");
        alert.setContentText("You need to select a member you need to edit");
        alert.showAndWait();
    }

    @FXML
    void editMemberBtnHandler(ActionEvent event) {
        Member memberSelected = membersTable.getSelectionModel().getSelectedItem();

        if (memberSelected == null) {
            showSelectTableRowError();
            return;
        }

        Parent root;
        FXMLLoader fxml = new FXMLLoader(getClass().getResource("editMember.fxml"));
        try {
            root = fxml.load();
            EditMemberController editMemberController = fxml.getController();
            editMemberController.initializeFields(memberSelected);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        ((BorderPane) (membersContainer.getParent())).setCenter(root);
    }

    public void displayMembers(Connection conn) throws SQLException {
        // Clear previous members before adding new ones
        membersTable.getItems().clear();

        String query = "SELECT * FROM Member ORDER BY MID";
        try (Statement stat = conn.createStatement();
             ResultSet result = stat.executeQuery(query)) {

            while (result.next()) {
                int mid = result.getInt("MID");
                String name = result.getString("Name");
                String gender = result.getString("Gender");
                String department = result.getString("Department");
                int numberBorrowed = result.getInt("NumberBorrowed");
                Member member = new Member(mid, name, gender, department, numberBorrowed);
                membersTable.getItems().add(member);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error retrieving members", e);
        }
    }

    @FXML
    private void addMemberBtnHandler(ActionEvent event) {
        loadPage("addMember");
    }

    public void loadPage(String page) {
        Parent root;

        FXMLLoader fxml = new FXMLLoader(getClass().getResource(page + ".fxml"));
        try {
            root = fxml.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        ((BorderPane) (membersContainer.getParent())).setCenter(root);
    }
}
