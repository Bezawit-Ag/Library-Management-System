package com.poli.lms;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;

public class EditBookController {

    @FXML
    private AnchorPane addBookContainer;

    @FXML
    private Button addBtn;

    @FXML
    private TextField authorField;

    @FXML
    private TextField availableField;

    @FXML
    private Button backToBooksBtn;

    @FXML
    private DatePicker publishedDateField;

    @FXML
    private TextField titleField;

    @FXML
    private CheckBox donatedCheckBox;  // Checkbox for donation status

    @FXML
    private TextField donorNameField;  // TextField for donor name

    private int isbn;

    @FXML
    void editBookBtnHandler(ActionEvent event) {
        try {
            Database.connect();

            // Validate the fields
            if (isbn <= 0 || titleField.getText().isEmpty()
                    || publishedDateField.getValue().toString().isEmpty() || authorField.getText().isEmpty()
                    || availableField.getText().isEmpty()) {

                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Book Error Dialog");
                alert.setHeaderText("Invalid Data");
                alert.setContentText("All fields must be filled");
                alert.showAndWait();
                return;
            }

            // Parse input values
            int available = Integer.parseInt(availableField.getText());
            boolean donated = donatedCheckBox.isSelected();  // Get donation status
            String donorName = donorNameField.getText();  // Get donor name

            // Call Database.editBook with the new parameters
            Database.editBook(isbn, titleField.getText(), authorField.getText(),
                    publishedDateField.getValue().toString(), available, donated, donorName);

            loadPage("books");

        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void backToBooksBtnHandler(ActionEvent event) {
        loadPage("books");
    }

    public void loadPage(String page) {
        Parent root;

        FXMLLoader fxml = new FXMLLoader(getClass().getResource(page + ".fxml"));
        try {
            root = fxml.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        ((BorderPane) (addBookContainer.getParent())).setCenter(root);
    }

    // Initialize the fields with the selected book's data
    public void initializeField(Book book) {
        isbn = book.getISBN();
        titleField.setText(book.getTitle());
        authorField.setText(book.getAuthor());
        publishedDateField.setValue(LocalDate.parse(book.getPublishedDate()));
        availableField.setText(Integer.toString(book.getAvailable()));

        // Set donation status and donor name (if applicable)
        donatedCheckBox.setSelected(book.isDonated());
        donorNameField.setText(book.getDonorName());
    }
}
