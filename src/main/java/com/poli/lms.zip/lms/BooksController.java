package com.poli.lms;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.concurrent.CancellationException;

public class BooksController implements Initializable {
    @FXML private AnchorPane booksContainer;
    @FXML private TextField searchField;

    @FXML private TableView<Book> booksTable;
    @FXML private TableColumn<Book, Integer> ISBNCol;
    @FXML private TableColumn<Book, String> titleCol;
    @FXML private TableColumn<Book, String> authorCol;
    @FXML private TableColumn<Book, String> publishedDateCol;
    @FXML private TableColumn<Book, Integer> availableCol;
    @FXML private TableColumn<Book, Boolean> donatedCol;
    @FXML private TableColumn<Book, String> donorNameCol;

    @FXML private TableView<BorrowedBook> borrowedBooksTable;
    @FXML private TableColumn<BorrowedBook, Integer> borrowedBookISBNCol;
    @FXML private TableColumn<BorrowedBook, String> borrowedBookTitleCol;
    @FXML private TableColumn<BorrowedBook, Integer> borrowerMIDCol;
    @FXML private TableColumn<BorrowedBook, String> borrowerIssueDateCol;
    @FXML private TableColumn<BorrowedBook, String> borrowerNameCol;

    private final ObservableList<Book> masterBookList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ISBNCol.setCellValueFactory(new PropertyValueFactory<>("ISBN"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        authorCol.setCellValueFactory(new PropertyValueFactory<>("author"));
        availableCol.setCellValueFactory(new PropertyValueFactory<>("available"));
        publishedDateCol.setCellValueFactory(new PropertyValueFactory<>("publishedDate"));
        donatedCol.setCellValueFactory(new PropertyValueFactory<>("donated"));
        donorNameCol.setCellValueFactory(new PropertyValueFactory<>("donorName"));

        borrowedBookISBNCol.setCellValueFactory(new PropertyValueFactory<>("ISBN"));
        borrowedBookTitleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        borrowerMIDCol.setCellValueFactory(new PropertyValueFactory<>("mid"));
        borrowerIssueDateCol.setCellValueFactory(new PropertyValueFactory<>("issueDate"));
        borrowerNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        try {
            Database.connect();
            displayBooks();
            displayBorrowedBooks();
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }

        setupSearch();
    }

    private void displayBooks() throws SQLException {
        ResultSet result = Database.getBooks();
        while (result.next()) {
            Book book = new Book(
                    result.getInt("ISBN"),
                    result.getString("Title"),
                    result.getString("Author"),
                    result.getString("PublishedDate"),
                    result.getInt("available"),
                    result.getBoolean("Donated"),
                    result.getString("DonorName")
            );
            masterBookList.add(book);
        }
        booksTable.setItems(masterBookList);
    }

    private void setupSearch() {
        FilteredList<Book> filteredBooks = new FilteredList<>(masterBookList, b -> true);

        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            String lowerCaseFilter = newVal.toLowerCase();

            filteredBooks.setPredicate(book -> {
                if (newVal.isEmpty()) return true;

                return String.valueOf(book.getISBN()).contains(lowerCaseFilter) ||
                        book.getTitle().toLowerCase().contains(lowerCaseFilter) ||
                        book.getAuthor().toLowerCase().contains(lowerCaseFilter);
            });
        });

        booksTable.setItems(filteredBooks);
    }

    public void displayBorrowedBooks() throws SQLException {
        ResultSet result = Database.getBorrowedBooks();
        while (result.next()) {
            BorrowedBook book = new BorrowedBook(
                    result.getInt("ISBN"),
                    result.getString("IssueDate"),
                    result.getInt("MID"),
                    result.getString("Name"),
                    result.getString("Title")
            );
            borrowedBooksTable.getItems().add(book);
        }
    }

    @FXML
    private void deleteBookHandler() {
        Book selectedBook = booksTable.getSelectionModel().getSelectedItem();
        if (selectedBook == null) {
            showSelectTableRowError();
            return;
        }

        try {
            Database.removeBook(selectedBook.getISBN());
            booksTable.getItems().remove(selectedBook);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    private void addBookBtnHandler(ActionEvent event) {
        loadPage("addBook");
    }

    @FXML
    private void editBtnHandler(ActionEvent event) {
        Book selectedBook = booksTable.getSelectionModel().getSelectedItem();
        if (selectedBook == null) {
            showSelectTableRowError();
            return;
        }

        try {
            FXMLLoader fxml = new FXMLLoader(getClass().getResource("editBook.fxml"));
            Parent root = fxml.load();
            EditBookController controller = fxml.getController();
            controller.initializeField(selectedBook);
            ((BorderPane) booksContainer.getParent()).setCenter(root);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void loadPage(String page) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(page + ".fxml"));
            ((BorderPane) booksContainer.getParent()).setCenter(root);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void showSelectTableRowError() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Book Error Dialog");
        alert.setHeaderText("First Select The Table Row");
        alert.setContentText("You need to select a book you need to edit");
        alert.showAndWait();
    }
}
