package com.poli.lms;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;

public class studentPropertyController {

    @FXML private TextField midField;
    @FXML private TextField deviceTypeField;
    @FXML private TextField deviceModelField;
    @FXML private TextField serialNumberField;
    @FXML private DatePicker entryDateField;

    @FXML private TableView<studentProperty> propertyTable;
    @FXML private TableColumn<studentProperty, Integer> midColumn;
    @FXML private TableColumn<studentProperty, String> deviceTypeColumn;
    @FXML private TableColumn<studentProperty, String> deviceModelColumn;
    @FXML private TableColumn<studentProperty, String> serialNumberColumn;
    @FXML private TableColumn<studentProperty, LocalDate> entryDateColumn;

    private final ObservableList<studentProperty> propertyList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Set up columns
        midColumn.setCellValueFactory(new PropertyValueFactory<>("mid"));
        deviceTypeColumn.setCellValueFactory(new PropertyValueFactory<>("deviceType"));
        deviceModelColumn.setCellValueFactory(new PropertyValueFactory<>("model"));
        serialNumberColumn.setCellValueFactory(new PropertyValueFactory<>("serial"));
        entryDateColumn.setCellValueFactory(new PropertyValueFactory<>("entryDate"));

        // Bind the observable list to the table
        propertyTable.setItems(propertyList);
    }

    @FXML
    private void handleRegisterEntry() {
        try {
            int mid = Integer.parseInt(midField.getText());
            String deviceType = deviceTypeField.getText();
            String model = deviceModelField.getText();
            String serial = serialNumberField.getText();
            LocalDate date = entryDateField.getValue();

            if (deviceType.isEmpty() || model.isEmpty() || serial.isEmpty() || date == null) {
                showAlert("Please fill all fields!");
                return;
            }

            Database.registerStudentProperty(mid, deviceType, model, serial, date.toString());
            propertyList.add(new studentProperty(mid, deviceType, model, serial, date));
            showAlert("Device registered successfully.");
            clearForm();
        } catch (NumberFormatException e) {
            showAlert("MID must be a number.");
        } catch (Exception e) {
            showAlert("Error: " + e.getMessage());
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Device Entry");
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void clearForm() {
        midField.clear();
        deviceTypeField.clear();
        deviceModelField.clear();
        serialNumberField.clear();
        entryDateField.setValue(null);
    }
}
