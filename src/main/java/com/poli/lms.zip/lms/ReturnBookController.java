package com.poli.lms;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.net.URL;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;


public class ReturnBookController implements Initializable {


        @FXML
        private TextField ISBNField;

        @FXML
        private TextField MIDField;

        @FXML
        private Text bookAuthor;

        @FXML
        private Text bookAvailable;

        @FXML
        private VBox bookContainer;

        @FXML
        private Text bookTitle;

        @FXML
        private Text memberBorrowed;

        @FXML
        private VBox memberContainer;

        @FXML
        private Text memberDepartment;

        @FXML
        private Text memberName;

        @FXML
        private Button returnBookBtn;


    @FXML
    void returnBookBtnHandler(ActionEvent event) {
        if (ISBNField.getText().isEmpty() || MIDField.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Return Book Warning Dialog");
            alert.setContentText("Please enter all fields");
            alert.setHeaderText("Some Fields are empty");
            alert.showAndWait();
            return;
        }

        int mid = Integer.parseInt(MIDField.getText());
        int isbn = Integer.parseInt(ISBNField.getText());

        try {
            Database.connect();
            Database.returnBook(mid, isbn);

            // ✅ Show success alert
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Book Returned");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Book returned successfully!");
            successAlert.showAndWait();

            resetFields();
        } catch (ClassNotFoundException | SQLException | ParseException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Return Book Error");
            alert.setHeaderText("Failed to Return Book");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }
    }

    private void resetFields(){
        MIDField.setText("");
        ISBNField.setText("");
    }

    @FXML
    void bookISBNKeyPressed(KeyEvent event) {
        if(ISBNField.getText().isEmpty()) {
            bookContainer.setVisible(false);
            return;
        };
        try {
            int ISBN = Integer.parseInt(ISBNField.getText());
            ResultSet result = Database.getBookByISBN(ISBN);

            if(result.next()){
                bookTitle.setText(result.getString(2));
                bookAuthor.setText(result.getString(3));
                bookAvailable.setText(result.getString(5));
                bookContainer.setVisible(true);
                return;
            }
            bookTitle.setText("Not found");
            bookAuthor.setText("Not found");
            bookAvailable.setText("Not Found");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void memberIdFieldKeyPressed(KeyEvent event) {
        if(MIDField.getText().isEmpty()) {
            memberContainer.setVisible(false);
            return;
        };
        try {
            int MID = Integer.parseInt(MIDField.getText());
            ResultSet result = Database.getMemberByMID(MID);
            if(result.next()){
                memberName.setText(result.getString(2));
                memberDepartment.setText(result.getString(4));
                memberBorrowed.setText(result.getString(5));
                memberContainer.setVisible(true);
                return;
            }
            memberName.setText("Not found");
            memberDepartment.setText("Not found");
            memberBorrowed.setText("Not found");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }




    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            Database.connect();
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
