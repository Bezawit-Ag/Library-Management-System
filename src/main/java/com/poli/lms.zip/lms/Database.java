package com.poli.lms;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.CancellationException;

public class Database {
    public static Connection connection;
    public static final int port = 3306;
    public static final String user = "root";
    public static final String password = "Sealitemihret1621";

    public static void connect() throws ClassNotFoundException, SQLException {
        if (connection != null && !connection.isClosed()) return;
        Class.forName("com.mysql.cj.jdbc.Driver");
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", user, password);
        System.out.println("Database connected successfully");
    }

    public static ResultSet getBookByISBN(int ISBN) throws SQLException {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM Book WHERE ISBN=?");
        statement.setInt(1, ISBN);
        return statement.executeQuery();
    }

    public static ResultSet getMemberByMID(int MID) throws SQLException {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM Member WHERE MID=?");
        statement.setInt(1, MID);
        return statement.executeQuery();
    }

    public static void editBook(int isbn, String title, String author, String pubDate, int available, boolean donated, String donorName) throws SQLException {
        String checkQuery = "SELECT * FROM Book WHERE ISBN=?";
        PreparedStatement checkStatement = connection.prepareStatement(checkQuery);
        checkStatement.setInt(1, isbn);
        ResultSet rs = checkStatement.executeQuery();

        if (!rs.next()) {
            showAlert(Alert.AlertType.ERROR, "Book Error", "Book Not Found", "No book found with the specified ISBN.");
            return;
        }

        String updateQuery = "UPDATE Book SET Title=?, Author=?, PublishedDate=?, Available=?, Donated=?, DonorName=? WHERE ISBN=?";
        PreparedStatement statement = connection.prepareStatement(updateQuery);
        statement.setString(1, title);
        statement.setString(2, author);
        statement.setString(3, pubDate);
        statement.setInt(4, available);
        statement.setBoolean(5, donated);
        statement.setString(6, donorName);
        statement.setInt(7, isbn);

        int rowsAffected = statement.executeUpdate();
        if (rowsAffected == 0) {
            showAlert(Alert.AlertType.ERROR, "Book Error", "Update Failed", "Failed to update the book details.");
        } else {
            showAlert(Alert.AlertType.INFORMATION, "Book Updated", "Update Successful", "Book details updated successfully.");
        }
    }

    public static void removeMember(int mid) throws Exception {
        String selectMemberQuery = "SELECT * FROM Member WHERE MID=?";
        String selectAdminQuery = "SELECT * FROM Admin WHERE MID=?";
        String deleteMemberQuery = "DELETE FROM Member WHERE MID=?";

        try (PreparedStatement stmt = connection.prepareStatement(selectMemberQuery)) {
            stmt.setInt(1, mid);
            ResultSet memberResult = stmt.executeQuery();

            if (!memberResult.next()) {
                throw new Exception("Member not found.");
            }

            try (PreparedStatement adminStmt = connection.prepareStatement(selectAdminQuery)) {
                adminStmt.setInt(1, mid);
                ResultSet adminResult = adminStmt.executeQuery();
                if (adminResult.next()) {
                    showAlert(Alert.AlertType.ERROR, "Member Error", "Admin Account Can't Be Altered", "You are not allowed to remove an Admin account.");
                    throw new Exception("Canceled");
                }
            }

            if (memberResult.getInt("NumberBorrowed") > 0) {
                showAlert(Alert.AlertType.ERROR, "Member Error", "Return Book Before Withdraw", "You have to return all the books before you withdraw as a member.");
                throw new Exception("Canceled");
            }

            String memberName = memberResult.getString("Name").trim();

            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete " + memberName + "'s data?", ButtonType.YES, ButtonType.NO);
            confirm.showAndWait();
            if (confirm.getResult() == ButtonType.YES) {
                try (PreparedStatement deleteStmt = connection.prepareStatement(deleteMemberQuery)) {
                    deleteStmt.setInt(1, mid);
                    deleteStmt.executeUpdate();
                    System.out.println("Member deleted successfully.");
                }
            } else {
                throw new Exception("Canceled");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error while trying to remove member", e);
        }
    }

    public static void removeBook(int isbn) throws SQLException {
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM Book WHERE ISBN=" + isbn);

        if (rs.next()) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete Book \"" + rs.getString("Title") + "\"?", ButtonType.YES, ButtonType.NO);
            alert.setHeaderText("This book might be acquired by other members");
            alert.showAndWait();

            if (alert.getResult() == ButtonType.YES) {
                stmt.executeUpdate("UPDATE Book SET Available=0 WHERE ISBN=" + isbn);
            } else {
                throw new CancellationException("Canceled");
            }
        }
    }

    public static ResultSet getBorrowedBooks() throws SQLException {
        String query = "SELECT b.MID, m.Name, b.ISBN, bk.Title, b.issueDate " +
                "FROM BorrowedBooks b " +
                "JOIN Member m ON b.MID = m.MID " +
                "JOIN Book bk ON b.ISBN = bk.ISBN";
        return connection.createStatement().executeQuery(query);
    }

    public static void editMember(int mid, String name, String gender, String department) throws SQLException {
        if (connection.createStatement().executeQuery("SELECT * FROM Admin WHERE MID=" + mid).next()) {
            showAlert(Alert.AlertType.ERROR, "Member Error", "Action Not Allowed", "You are not allowed to edit admin account.");
            return;
        }

        PreparedStatement stmt = connection.prepareStatement("UPDATE Member SET Name=?, Gender=?, Department=? WHERE MID=?");
        stmt.setString(1, name);
        stmt.setString(2, gender);
        stmt.setString(3, department);
        stmt.setInt(4, mid);
        stmt.executeUpdate();
    }

    public static void addBook(int isbn, String title, String author, String pubDate, int available) throws SQLException {
        PreparedStatement stmt = connection.prepareStatement(
                "INSERT INTO Book (ISBN, Title, Author, PublishedDate, Available, Donated, DonorName) VALUES (?, ?, ?, ?, ?, false, null)"
        );
        stmt.setInt(1, isbn);
        stmt.setString(2, title);
        stmt.setString(3, author);
        stmt.setString(4, pubDate);
        stmt.setInt(5, available);
        stmt.executeUpdate();
    }

    public static void addBook(int isbn, String title, String author, String pubDate, int available, boolean donated, String donorName) throws SQLException {
        PreparedStatement stmt = connection.prepareStatement(
                "INSERT INTO Book (ISBN, Title, Author, PublishedDate, Available, Donated, DonorName) VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        stmt.setInt(1, isbn);
        stmt.setString(2, title);
        stmt.setString(3, author);
        stmt.setString(4, pubDate);
        stmt.setInt(5, available);
        stmt.setBoolean(6, donated);
        stmt.setString(7, donorName);
        stmt.executeUpdate();
    }

    public static ResultSet getBooks() throws SQLException {
        return connection.createStatement().executeQuery("SELECT * FROM Book ORDER BY Available");
    }

    public static ResultSet getDonatedBooks() throws SQLException {
        String query = "SELECT * FROM Book WHERE Donated = TRUE";
        return connection.createStatement().executeQuery(query);
    }

    public static void addMember(int mid, String name, String gender, String department, int numberBorrowed) throws SQLException {
        PreparedStatement stmt = connection.prepareStatement("INSERT INTO Member VALUES (?, ?, ?, ?, ?)");
        stmt.setInt(1, mid);
        stmt.setString(2, name);
        stmt.setString(3, gender);
        stmt.setString(4, department);
        stmt.setInt(5, numberBorrowed);
        stmt.executeUpdate();
    }

    public static ResultSet getMembers() throws SQLException {
        return connection.createStatement().executeQuery("SELECT * FROM Member ORDER BY MID");
    }

    public static void issueBook(int mid, int isbn) throws SQLException {
        ResultSet bookResult = connection.createStatement().executeQuery("SELECT * FROM Book WHERE ISBN=" + isbn);
        if (!bookResult.next()) {
            showAlert(Alert.AlertType.ERROR, "Issue Book Error", "Book Doesn't Exist", "The book you are looking for doesn't exist in the library.");
            return;
        }

        if (bookResult.getInt("Available") <= 0) {
            showAlert(Alert.AlertType.ERROR, "Issue Book Error", "No Copies Left", "This book has no copies left.");
            return;
        }

        ResultSet memberResult = connection.createStatement().executeQuery("SELECT * FROM Member WHERE MID=" + mid);
        if (!memberResult.next()) {
            showAlert(Alert.AlertType.ERROR, "Issue Book Error", "Member Not Found", "Member doesn't exist with the given ID.");
            return;
        }

        if (memberResult.getInt("NumberBorrowed") >= 5) {
            showAlert(Alert.AlertType.ERROR, "Issue Book Error", "Reached Maximum Borrowing Capacity", "The member reached the maximum limit for borrowing books.");
            return;
        }

        String issueDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        connection.createStatement().executeUpdate("UPDATE Book SET Available=Available-1 WHERE ISBN=" + isbn);
        connection.createStatement().executeUpdate("UPDATE Member SET NumberBorrowed=NumberBorrowed+1 WHERE MID=" + mid);
        connection.createStatement().executeUpdate("INSERT INTO BorrowedBooks (MID, ISBN, IssueDate) VALUES(" + mid + ", " + isbn + ", '" + issueDate + "')");
    }

    public static void returnBook(int mid, int isbn) throws SQLException, ParseException {
        ResultSet borrowedBooks = connection.createStatement().executeQuery("SELECT * FROM BorrowedBooks WHERE MID=" + mid + " AND ISBN=" + isbn);

        if (!borrowedBooks.next()) {
            showAlert(Alert.AlertType.ERROR, "Return Book Error", "Invalid Details", "You have been provided with invalid details.");
            return;
        }

        String issueDate = borrowedBooks.getString("IssueDate");
        Date borrowedDate = new SimpleDateFormat("yyyy-MM-dd").parse(issueDate);
        long days = (new Date().getTime() - borrowedDate.getTime()) / (1000 * 60 * 60 * 24);

        connection.createStatement().executeUpdate("UPDATE Book SET Available=Available+1 WHERE ISBN=" + isbn);
        connection.createStatement().executeUpdate("UPDATE Member SET NumberBorrowed=NumberBorrowed-1 WHERE MID=" + mid);
        connection.createStatement().executeUpdate("DELETE FROM BorrowedBooks WHERE MID=" + mid + " AND ISBN=" + isbn);

        if (days > 7) {
            showAlert(Alert.AlertType.WARNING, "Return Book Warning", "Late Book Return", "You haven't returned the book for more than 7 days.");
        }
    }

    private static void showAlert(Alert.AlertType type, String title, String header, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();

    }

    public static void registerStudentProperty(int mid, String deviceType, String model, String serial, String date) throws SQLException {
        String insertQuery = "INSERT INTO StudentProperty (MID, DeviceType, Model, SerialNumber, EntryDate) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement stmt = connection.prepareStatement(insertQuery);
        stmt.setInt(1, mid);
        stmt.setString(2, deviceType);
        stmt.setString(3, model);
        stmt.setString(4, serial);
        stmt.setString(5, date);
        stmt.executeUpdate();
    }
}